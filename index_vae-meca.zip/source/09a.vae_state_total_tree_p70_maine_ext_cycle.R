# Initialize
source("00.initialize.R")
# Load plots_p70 (combined previous and current cycle data) for Maine
load(file.path("data","plots_p70_me.Rdata"))
# Load current cycle data for Maine
load(file.path("data","total_vol_me.Rdata"))

changes <- plots_p70$VOLCFNET_plot_change[plots_p70$PLOT_STATUS_CD==1&
                                            !is.na(plots_p70$VOLCFNET_plot_change)]

# Determine the largest negative annualized change value and add 1
shift <- abs(min(changes)) + 1
# then add this value to all annualized change values to eliminate non-positive values
# (because Weibull distribution can't handle negative and 0 values)
shifted_changes <- changes + shift

# Fit Weibull distribution to the shifted annualized change values
library(fitdistrplus)
fit <- fitdist(shifted_changes, "weibull")
fit[1]$estimate[1]
fit[1]$estimate[2]

plot(density(changes),
     main = "Change in annualized plot-level volume, previous to current cycle")
lines(density(rweibull(n=1000000,
                       shape = fit[1]$estimate[1],
                       scale = fit[1]$estimate[2])-shift),
      col="red")
lines(density(rweibull(n=1000000,
                       shape = 13.86533,
                       scale = 922.7328)-878),
      col="blue")

mean(rweibull(n=100000,shape = fit[1]$estimate[1],
              scale = fit[1]$estimate[2]))-shift

### SLOW START SCENARIO
# Here, we simulate a slow start (Some panel 70's pushed forward from first few P2 panels)
ext_cycle <- plots_p70

# NEED TO ACOUNT FOR THE FACT THAT 2020 INVYR WAS NOT PANEL70 1-14, 2020 STARTED WITH P70=15 as the following shows:
table(plots_p70$INVYR,plots_p70$PANEL_70)
table(plots_p70$P2PANEL,plots_p70$PANEL_70) # P70's are aligned with P2 Panels, not necessarily INVYRS at beginning of cycle...
# I.e., as the following shows for Maine,
table(plots_p70$INVYR) # Original INVYR distribution
table(ceiling(plots_p70$PANEL_70/14)) # How many P70's per panel in 5 year cycle?

table(plots_p70$INVYR,plots_p70$PANEL_70)

# what prop/pct of plots are meant to be measured in each INVYR?
invyrs <- unique(sort(ext_cycle$INVYR))
props_measured <- vector(mode = "numeric", length = length(invyrs))
for(i in 1:length(invyrs)){
  props_measured[i] <- nrow(ext_cycle[ext_cycle$INVYR==invyrs[i],])/nrow(ext_cycle)
}

round(props_measured*100,2) # 20.38 / 20.07 / 19.95 / 19.84 / 19.75

# P70 values are staggered off of the INVYRS  2020-2024 by one panel... 
# I.e., 2020 = P70 15 - 28, etc...

### Seven year cycle length: 10 P70's/INVYR
ext_cycle$NEWINVYR_7 <- 0
for(i in 1:nrow(ext_cycle)){
  if(ext_cycle$PANEL_70[i] > 14 & ext_cycle$PANEL_70[i] <= 24){ext_cycle$NEWINVYR_7[i] <- 2020} else 
    if(ext_cycle$PANEL_70[i] > 24 & ext_cycle$PANEL_70[i] <= 34){ext_cycle$NEWINVYR_7[i] <- 2021} else 
      if(ext_cycle$PANEL_70[i] > 34 & ext_cycle$PANEL_70[i] <= 44){ext_cycle$NEWINVYR_7[i] <- 2022} else 
        if(ext_cycle$PANEL_70[i] > 44 & ext_cycle$PANEL_70[i] <= 54){ext_cycle$NEWINVYR_7[i] <- 2023} else 
          if(ext_cycle$PANEL_70[i] > 54 & ext_cycle$PANEL_70[i] <= 64){ext_cycle$NEWINVYR_7[i] <- 2024} else 
            if(ext_cycle$PANEL_70[i] > 64 & ext_cycle$PANEL_70[i] <= 70){ext_cycle$NEWINVYR_7[i] <- 2025} else 
              if(ext_cycle$PANEL_70[i] > 0 & ext_cycle$PANEL_70[i] <= 4){ext_cycle$NEWINVYR_7[i] <- 2025} else # had to add this because it wouldn't let me span 0???
                if(ext_cycle$PANEL_70[i] > 4 & ext_cycle$PANEL_70[i] <= 14){ext_cycle$NEWINVYR_7[i] <- 2026} 
}

table(ext_cycle$INVYR) # Original INVYR distribution
table(ext_cycle$NEWINVYR_7,useNA = "always") # New INVYR distribution

# Under this VAE regimen, what prop/pct of plots are measured in each INVYR?
invyrs <- unique(sort(ext_cycle$NEWINVYR_7))
props_measured <- vector(mode = "numeric", length = length(invyrs))
for(i in 1:length(invyrs)){
  props_measured[i] <- nrow(ext_cycle[ext_cycle$NEWINVYR_7==invyrs[i],])/nrow(ext_cycle)
}

round(props_measured*100,2) # 14.38 / 14.61 / 14.38 / 14.09 / 14.41 / 14.04 / 14.09

# For plots getting shifted forward, compute difference in years between original INVYR and new INVYR
#ext_cycle$INVDIFF <- ext_cycle$NEWINVYR_7 - ext_cycle$INVYR_0
ext_cycle$INVDIFF_7 <- ext_cycle$NEWINVYR_7 - ext_cycle$INVYR
table(ext_cycle$INVDIFF_7,useNA = "always") 

### Ten year cycle length: 7 P70's/INVYR
ext_cycle$NEWINVYR_10 <- 0
for(i in 1:nrow(ext_cycle)){
  if(ext_cycle$PANEL_70[i] > 14 & ext_cycle$PANEL_70[i] <= 21){ext_cycle$NEWINVYR_10[i] <- 2020} else 
    if(ext_cycle$PANEL_70[i] > 21 & ext_cycle$PANEL_70[i] <= 28){ext_cycle$NEWINVYR_10[i] <- 2021} else 
      if(ext_cycle$PANEL_70[i] > 28 & ext_cycle$PANEL_70[i] <= 35){ext_cycle$NEWINVYR_10[i] <- 2022} else 
        if(ext_cycle$PANEL_70[i] > 35 & ext_cycle$PANEL_70[i] <= 42){ext_cycle$NEWINVYR_10[i] <- 2023} else 
          if(ext_cycle$PANEL_70[i] > 42 & ext_cycle$PANEL_70[i] <= 49){ext_cycle$NEWINVYR_10[i] <- 2024} else 
            if(ext_cycle$PANEL_70[i] > 49 & ext_cycle$PANEL_70[i] <= 56){ext_cycle$NEWINVYR_10[i] <- 2025} else 
              if(ext_cycle$PANEL_70[i] > 56 & ext_cycle$PANEL_70[i] <= 63){ext_cycle$NEWINVYR_10[i] <- 2026} else
                if(ext_cycle$PANEL_70[i] > 63 & ext_cycle$PANEL_70[i] <= 70){ext_cycle$NEWINVYR_10[i] <- 2027} else
                  if(ext_cycle$PANEL_70[i] > 0 & ext_cycle$PANEL_70[i] <= 7){ext_cycle$NEWINVYR_10[i] <- 2028} else
                    if(ext_cycle$PANEL_70[i] > 7 & ext_cycle$PANEL_70[i] <= 14){ext_cycle$NEWINVYR_10[i] <- 2029} 
}

table(ext_cycle$INVYR) # Original INVYR distribution
table(ext_cycle$NEWINVYR_10) # New INVYR distribution

# Under this VAE regimen, what prop/pct of plots are measured in each INVYR?
invyrs <- unique(sort(ext_cycle$NEWINVYR_10))
props_measured <- vector(mode = "numeric", length = length(invyrs))
for(i in 1:length(invyrs)){
  props_measured[i] <- nrow(ext_cycle[ext_cycle$NEWINVYR_10==invyrs[i],])/nrow(ext_cycle)
}

round(props_measured*100,2) # 10.18 / 10.21 / 10.06 / 10.01 / 10.01 / 9.95 / 10.09 / 9.75 / 10.03 / 9.72

# For plots getting shifted forward, compute difference in years between original INVYR and new INVYR
#ext_cycle$INVDIFF <- ext_cycle$NEWINVYR_10 - ext_cycle$INVYR_0
ext_cycle$INVDIFF_10 <- ext_cycle$NEWINVYR_10 - ext_cycle$INVYR
table(ext_cycle$INVDIFF_10,useNA = "always") # So in Maine under this case 

### 14 year cycle length: 5 P70's/INVYR
ext_cycle$NEWINVYR_14 <- 0
for(i in 1:nrow(ext_cycle)){
  if(ext_cycle$PANEL_70[i] > 14 & ext_cycle$PANEL_70[i] <= 19){ext_cycle$NEWINVYR_14[i] <- 2020} else 
    if(ext_cycle$PANEL_70[i] > 19 & ext_cycle$PANEL_70[i] <= 24){ext_cycle$NEWINVYR_14[i] <- 2021} else 
      if(ext_cycle$PANEL_70[i] > 24 & ext_cycle$PANEL_70[i] <= 29){ext_cycle$NEWINVYR_14[i] <- 2022} else 
        if(ext_cycle$PANEL_70[i] > 29 & ext_cycle$PANEL_70[i] <= 34){ext_cycle$NEWINVYR_14[i] <- 2023} else 
          if(ext_cycle$PANEL_70[i] > 34 & ext_cycle$PANEL_70[i] <= 39){ext_cycle$NEWINVYR_14[i] <- 2024} else 
            if(ext_cycle$PANEL_70[i] > 39 & ext_cycle$PANEL_70[i] <= 44){ext_cycle$NEWINVYR_14[i] <- 2025} else 
              if(ext_cycle$PANEL_70[i] > 44 & ext_cycle$PANEL_70[i] <= 49){ext_cycle$NEWINVYR_14[i] <- 2026} else
                if(ext_cycle$PANEL_70[i] > 49 & ext_cycle$PANEL_70[i] <= 54){ext_cycle$NEWINVYR_14[i] <- 2027} else
                  if(ext_cycle$PANEL_70[i] > 54 & ext_cycle$PANEL_70[i] <= 59){ext_cycle$NEWINVYR_14[i] <- 2028} else
                    if(ext_cycle$PANEL_70[i] > 59 & ext_cycle$PANEL_70[i] <= 64){ext_cycle$NEWINVYR_14[i] <- 2029} else
                      if(ext_cycle$PANEL_70[i] > 64 & ext_cycle$PANEL_70[i] <= 69){ext_cycle$NEWINVYR_14[i] <- 2030} else
                        if(ext_cycle$PANEL_70[i] == 70){ext_cycle$NEWINVYR_14[i] <- 2031} else
                        if(ext_cycle$PANEL_70[i] > 0 & ext_cycle$PANEL_70[i] <= 4){ext_cycle$NEWINVYR_14[i] <- 2031} else
                          if(ext_cycle$PANEL_70[i] > 4 & ext_cycle$PANEL_70[i] <= 9){ext_cycle$NEWINVYR_14[i] <- 2032} else
                            if(ext_cycle$PANEL_70[i] > 9 & ext_cycle$PANEL_70[i] <= 14){ext_cycle$NEWINVYR_14[i] <- 2033} 
}

table(ext_cycle$INVYR) # Original INVYR distribution
table(ext_cycle$NEWINVYR_14) # New INVYR distribution

# Under this VAE regimen, what prop/pct of plots are measured in each INVYR?
invyrs <- unique(sort(ext_cycle$NEWINVYR_14))
props_measured <- vector(mode = "numeric", length = length(invyrs))
for(i in 1:length(invyrs)){
  props_measured[i] <- nrow(ext_cycle[ext_cycle$NEWINVYR_14==invyrs[i],])/nrow(ext_cycle)
}

round(props_measured*100,2) # 7.26 / 7.12 / 7.40 / 7.20 / 7.20 / 7.18 / 7.09 / 7.00 / 7.18 / 7.23 / 7.03 / 7.00 / 7.23 / 6.86

# For plots getting shifted forward, compute difference in years between original INVYR and new INVYR
#ext_cycle$INVDIFF <- ext_cycle$NEWINVYR_14 - ext_cycle$INVYR_0
ext_cycle$INVDIFF_14 <- ext_cycle$NEWINVYR_14 - ext_cycle$INVYR
table(ext_cycle$INVDIFF_14,useNA = "always") # So in Maine under this case 

nsim <- 1000

ext_cycle_results <- data.frame(matrix(NA, nrow = nsim, ncol = 6))
colnames(ext_cycle_results) <- c("total_7","se_pct_7", "total_10","se_pct_10", "total_14","se_pct_14")

#i <- 1

for(i in 1:nsim){
  # Set the seed to get same random draws in future simulations
  set.seed(i)
  # draw vector of random annual volume growth values
  growths <- rweibull(n=nrow(ext_cycle), shape = fit[1]$estimate[1], scale = fit[1]$estimate[2]) - shift
  
  # initiate new volume variables for the 3 different extended cycle lengths
  ext_cycle$NEWVOL_7 <- ext_cycle$NEWVOL_10 <- ext_cycle$NEWVOL_14 <- 0
  
  # Compute new volumes for 7 year cycle
  ext_cycle$NEWVOL_7 <- ifelse(ext_cycle$PLOT_STATUS_CD==1,
                               ext_cycle$VOLCFNET_plot + (ext_cycle$INVDIFF_7 * growths),
                               0)
  ext_cycle$NEWVOL_7 <- ifelse(ext_cycle$NEWVOL_7 < 0, 0, ext_cycle$NEWVOL_7)
  
  # Compute new volumes for 10 year cycle
  ext_cycle$NEWVOL_10 <- ifelse(ext_cycle$PLOT_STATUS_CD==1,
                                ext_cycle$VOLCFNET_plot + (ext_cycle$INVDIFF_10 * growths),
                               0)
  ext_cycle$NEWVOL_10 <- ifelse(ext_cycle$NEWVOL_10 < 0, 0, ext_cycle$NEWVOL_10)

  # Compute new volumes for 14 year cycle
  ext_cycle$NEWVOL_14 <- ifelse(ext_cycle$PLOT_STATUS_CD==1,
                                ext_cycle$VOLCFNET_plot + (ext_cycle$INVDIFF_14 * growths),
                               0)
  ext_cycle$NEWVOL_14 <- ifelse(ext_cycle$NEWVOL_14 < 0, 0, ext_cycle$NEWVOL_14)
  
  # Compare original volumes to new "grown" volumes
  # plot(density(plots_p70$VOLCFNET_plot))
  # lines(density(ext_cycle$NEWVOL),col="red")
  # summary(ext_cycle$VOLCFNET_plot)
  # summary(ext_cycle$NEWVOL)
  
  # Compute the ith new estimated total in the simulation 
  NEW_ESTIMATED_TOTAL_7 <- sum(ext_cycle$NEWVOL_7 * ext_cycle$EXPNS)
  NEW_ESTIMATED_TOTAL_10 <- sum(ext_cycle$NEWVOL_10 * ext_cycle$EXPNS)
  NEW_ESTIMATED_TOTAL_14 <- sum(ext_cycle$NEWVOL_14 * ext_cycle$EXPNS)
  
  # SE
  
  # get within stratum standard errors [GB2 eq 4 on page 8]
  v_Yhd_new <- aggregate(cbind(ext_cycle$NEWVOL_7,
                               ext_cycle$NEWVOL_10,
                               ext_cycle$NEWVOL_14),
                         by=list(ESTN_UNIT=ext_cycle$ESTN_UNIT,
                                 STRATUMCD=ext_cycle$STRATUMCD),
                         FUN=function(z){var(z)/length(z)}) 
  # note: var includes /(n-1), /n added via /length(z)
  
  colnames(v_Yhd_new)[ncol(v_Yhd_new)-2] <- "VOLCFNET_eu_strat_se_7"
  colnames(v_Yhd_new)[ncol(v_Yhd_new)-1] <- "VOLCFNET_eu_strat_se_10"
  colnames(v_Yhd_new)[ncol(v_Yhd_new)] <- "VOLCFNET_eu_strat_se_14"
  
  # add the stratum point/pixel count stuff to the latter
  v_Yhd_plus_total_new <- merge(v_Yhd_new,pop_stratum)
  
  # copy the list of estimation units for building estn unit level variances 
  pop_estn_unit_total_new <- pop_estn_unit_total
  pop_estn_unit_total_new$var_vol_new_7 <- 0
  pop_estn_unit_total_new$var_vol_new_10 <- 0
  pop_estn_unit_total_new$var_vol_new_14 <- 0
  # loop through the estn units
  for (eu in unique(pop_estn_unit_total$ESTN_UNIT)){
    # pull all strata in this estn unit
    strata_in_unit <- v_Yhd_plus_total_new[v_Yhd_plus_total_new$ESTN_UNIT==eu,]
    # get the W_h weights for each strata within the estimation unit
    strata_in_unit$W_h <- strata_in_unit$P1POINTCNT/sum(strata_in_unit$P1POINTCNT)
    # get the total p2 sample size in this estimation unit
    n <- sum(strata_in_unit$P2POINTCNT)
    # implement GB2 equation 3 page 8 in two parts for this estimation unit
    part1_7 <- sum(with(strata_in_unit,W_h*P2POINTCNT*VOLCFNET_eu_strat_se_7))
    part2_7 <- sum(with(strata_in_unit,(1-W_h)*P2POINTCNT*VOLCFNET_eu_strat_se_7)/n)
    # implement GB2 equation 3 page 8 in two parts for this estimation unit
    part1_10 <- sum(with(strata_in_unit,W_h*P2POINTCNT*VOLCFNET_eu_strat_se_10))
    part2_10 <- sum(with(strata_in_unit,(1-W_h)*P2POINTCNT*VOLCFNET_eu_strat_se_10)/n)
    # implement GB2 equation 3 page 8 in two parts for this estimation unit
    part1_14 <- sum(with(strata_in_unit,W_h*P2POINTCNT*VOLCFNET_eu_strat_se_14))
    part2_14 <- sum(with(strata_in_unit,(1-W_h)*P2POINTCNT*VOLCFNET_eu_strat_se_14)/n)
    # stick the result on the  copied list of estimation units
    pop_estn_unit_total_new$var_vol_new_7[pop_estn_unit_total_new$ESTN_UNIT==eu] <- (part1_7 + part2_7)/n
    pop_estn_unit_total_new$var_vol_new_10[pop_estn_unit_total_new$ESTN_UNIT==eu] <- (part1_10 + part2_10)/n
    pop_estn_unit_total_new$var_vol_new_14[pop_estn_unit_total_new$ESTN_UNIT==eu] <- (part1_14 + part2_14)/n
  }
  
  # combine the estimation unit level variances together, using the area variable
  total_var_new_7 <- sum(pop_estn_unit_total_new$var_vol_new_7*pop_estn_unit_total_new$AREA_USED^2)
  se_new_7 <- sqrt(total_var_new_7)
  total_var_new_10 <- sum(pop_estn_unit_total_new$var_vol_new_10*pop_estn_unit_total_new$AREA_USED^2)
  se_new_10 <- sqrt(total_var_new_10)
  total_var_new_14 <- sum(pop_estn_unit_total_new$var_vol_new_14*pop_estn_unit_total_new$AREA_USED^2)
  se_new_14 <- sqrt(total_var_new_14)
  
  #se_new / NEW_ESTIMATED_TOTAL * 100 # Compute new SE%
  
  ext_cycle_results$total_7[i] <- NEW_ESTIMATED_TOTAL_7
  ext_cycle_results$se_pct_7[i] <- se_new_7 / NEW_ESTIMATED_TOTAL_7 * 100
  ext_cycle_results$total_10[i] <- NEW_ESTIMATED_TOTAL_10
  ext_cycle_results$se_pct_10[i] <- se_new_10 / NEW_ESTIMATED_TOTAL_10 * 100
  ext_cycle_results$total_14[i] <- NEW_ESTIMATED_TOTAL_14
  ext_cycle_results$se_pct_14[i] <- se_new_14 / NEW_ESTIMATED_TOTAL_14 * 100
}

head(ext_cycle_results)

total_var <- sum(pop_estn_unit_total$var_vol*pop_estn_unit_total$AREA_USED^2)
se_pct_me <- sqrt(total_var) / ESTIMATED_TOTAL * 100

# Rename some stuff, and save fast/slow results for ME
ext_cycle_results_me <- ext_cycle_results
ESTIMATED_TOTAL_me <- ESTIMATED_TOTAL 

save(ext_cycle_results_me,ESTIMATED_TOTAL_me,se_pct_me,file=file.path("data","ext_cycle_me.Rdata"))

x_bump <- 0.08
y_bump <- 0.05

t_blk <- rgb(0, 0, 0, alpha = 128, maxColorValue = 255)
t_grn <- rgb(0, 155, 0, alpha = 128, maxColorValue = 255)
t_org <- rgb(255, 69, 0, alpha = 128, maxColorValue = 255)

plot(ESTIMATED_TOTAL_me, se_pct_me, col="red", pch = 19,
     ylab = "Standard Error (% of Estimated Total)", xlab = "Percent Change in Estimated Total",
     ylim = c(se_pct_me - (y_bump), se_pct_me + (y_bump)),
     xlim = c(ESTIMATED_TOTAL_me - (x_bump*ESTIMATED_TOTAL_me),ESTIMATED_TOTAL_me + (x_bump*ESTIMATED_TOTAL_me)),
     xaxt = "n",
     main = "Maine")
points(ext_cycle_results$total_7,ext_cycle_results$se_pct_7, pch=19, col = t_blk) # 7 year cycle
points(ext_cycle_results$total_10,ext_cycle_results$se_pct_10, pch=19, col = t_grn) # 10 year cycle
points(ext_cycle_results$total_14,ext_cycle_results$se_pct_14, pch=19, col = t_org) # 14 year cycle

x_vals <- ESTIMATED_TOTAL_me * (1 + seq(-0.1, 0.1, by = 0.005))
axis(side = 1, at = x_vals, labels = paste0(round(seq(-10.0, 10.0, 0.5),1), "%"))
abline(h = se_pct_me, v = ESTIMATED_TOTAL_me, col = "lightgray", lty = 3)
points(ESTIMATED_TOTAL_me, se_pct_me, col="red", pch = 19)

legend("bottomleft", 
       legend = c("Original Estimate","7 Year Cycle", "10 Year Cycle", "14 Year Cycle"), 
       col = c("red",t_blk, t_grn, t_org), 
       pch = 19, 
       title = "VAE Regimen")
